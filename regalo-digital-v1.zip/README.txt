# Regalo Digital — primera versión

Esta es la primera maqueta funcional de nuestra plataforma.

## Cómo abrirla

1. Descomprime el archivo ZIP.
2. Abre la carpeta.
3. Haz doble clic en `index.html`.
4. Se abrirá en tu navegador.

No necesitas instalar nada para ver esta primera versión.

## Próximas etapas

- Personalizador para nombre, fecha, textos y colores.
- Subida de fotos.
- Música personalizada.
- URL única para cada regalo.
- Generación automática de códigos QR.
- Panel para crear y administrar regalos.
- Base de datos y almacenamiento de imágenes.
- Diseño premium y sistema de pagos.
